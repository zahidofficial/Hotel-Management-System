<?php 
session_start();

// Database connection
$conn = mysqli_connect("localhost", "root", "", "hotel");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetching requests data along with related customer and room information
$sql = "
    SELECT r.request_id, u.name AS customer_name, rm.room_category, 
           b.total_amount AS rent, b.start_date, b.end_date, 
           DATEDIFF(b.end_date, b.start_date) AS stay_duration, 
           r.feedback AS customer_feedback, r.status 
    FROM requests r
    JOIN users u ON r.customer_id = u.user_id
    JOIN rooms rm ON r.room_id = rm.room_id
    JOIN bookings b ON r.customer_id = b.customer_id AND r.room_id = b.room_id
";

$result = mysqli_query($conn, $sql);
$requests = [];

if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        $requests[] = $row; // Store each request in the $requests array
    }
} else {
    echo "No requests available.";
}

mysqli_close($conn); // Close the database connection
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Request</title>
    <link rel="stylesheet" href="css/cssDash.css">
    <style>
        /* Style for the form */
        .request-container {
            margin-top: 20px;
        }
        .request-table {
            width: 100%;
            border-collapse: collapse;
        }
        .request-table, .request-table th, .request-table td {
            border: 1px solid black;
        }
        .request-table th, .request-table td {
            padding: 10px;
            text-align: left;
        }
        .request-table th {
            background-color: #f2f2f2;
        }
        /* Style for buttons */
        .action-btn {
            background-color: #4CAF50; /* Green background */
            color: white; /* White text */
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-right: 5px;
        }
        .action-btn.reject {
            background-color: #f44336; /* Red background */
        }
        .action-btn:hover {
            opacity: 0.8; /* Slightly dim on hover */
        }
        .status-btn {
            background-color: #2196F3; /* Blue background */
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
        }
    </style>
</head>
<body>

    <div class="header">View Requests</div>

    <div class="container">
        <div class="request-container">
            <h2>Customer Requests</h2>
            <table class="request-table">
                <tr>
                    <th>Customer Name</th>
                    <th>Room Category</th>
                    <th>Rent</th>
                    <th>Duration</th>
                    <th>Days</th>
                    <th>Customer Feedback</th>
                    <th>Feedback</th>
                    <th>Actions</th>
                </tr>
                <?php foreach ($requests as $request): ?>
                <tr>
                    <td><?php echo htmlspecialchars($request['customer_name']); ?></td>
                    <td><?php echo htmlspecialchars($request['room_category']); ?></td>
                    <td>$<?php echo htmlspecialchars($request['rent']); ?></td>
                    <td>
                        Start: <?php echo htmlspecialchars($request['start_date']); ?><br>
                        End: <?php echo htmlspecialchars($request['end_date']); ?>
                    </td>
                    <td><?php echo htmlspecialchars($request['stay_duration']); ?></td>
                    <td><textarea rows="3" cols="30" placeholder="Customer feedback..."><?php echo htmlspecialchars($request['customer_feedback']); ?></textarea></td>
                    <td><textarea rows="3" cols="30" placeholder="Send feedback..."></textarea></td>
                    <td>
                        <div id="action-buttons-<?php echo $request['request_id']; ?>">
                            <?php if ($request['status'] === 'Pending'): ?>
                                <button class="action-btn" onclick="updateRequestStatus(<?php echo $request['request_id']; ?>, 'Accepted')">Accept</button>
                                <button class="action-btn reject" onclick="updateRequestStatus(<?php echo $request['request_id']; ?>, 'Rejected')">Reject</button>
                            <?php else: ?>
                                <button class="status-btn"><?php echo htmlspecialchars($request['status']); ?></button>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>

    <div class="footer">
        <!-- Optional Footer content -->
    </div>

    <script>
        function updateRequestStatus(requestId, status) {
            const xhr = new XMLHttpRequest();
            xhr.open("POST", "UpdateRequestStatus.php", true); // Update the path if necessary
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        const response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            alert('Request ' + requestId + ' status updated to ' + status + '!');
                            document.getElementById('action-buttons-' + requestId).innerHTML = '<button class="status-btn">' + status + '</button>';
                        } else {
                            alert('Error: ' + response.message);
                        }
                    } else {
                        alert('Request failed with status: ' + xhr.status);
                    }
                }
            };
            xhr.send("request_id=" + requestId + "&status=" + status);
        }
    </script>

</body>
</html>

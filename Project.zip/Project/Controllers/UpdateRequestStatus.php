<?php
session_start();

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$conn = mysqli_connect("localhost", "root", "", "hotel");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the request_id and status from the POST data
    $request_id = isset($_POST['request_id']) ? intval($_POST['request_id']) : 0;
    $status = isset($_POST['status']) ? mysqli_real_escape_string($conn, $_POST['status']) : '';

    // Validate inputs
    if ($request_id > 0 && !empty($status)) {
        // Prepare the SQL statement to prevent SQL injection
        $sql = "UPDATE requests SET status = ? WHERE request_id = ?";
        $stmt = mysqli_prepare($conn, $sql);

        if ($stmt) {
            // Bind parameters
            mysqli_stmt_bind_param($stmt, 'si', $status, $request_id);
            // Execute the statement
            if (mysqli_stmt_execute($stmt)) {
                // Return a success message
                header('Content-Type: application/json');
                echo json_encode(["success" => true, "message" => "Request status updated successfully."]);
            } else {
                // Return an error message
                header('Content-Type: application/json');
                echo json_encode(["success" => false, "message" => "Error updating request status: " . mysqli_error($conn)]);
            }
            mysqli_stmt_close($stmt);
        } else {
            // Return a preparation error message
            header('Content-Type: application/json');
            echo json_encode(["success" => false, "message" => "Error preparing statement: " . mysqli_error($conn)]);
        }
    } else {
        // Return invalid data message
        header('Content-Type: application/json');
        echo json_encode(["success" => false, "message" => "Invalid request data."]);
    }
} else {
    // Return invalid request method message
    header('Content-Type: application/json');
    echo json_encode(["success" => false, "message" => "Invalid request method."]);
}

mysqli_close($conn); // Close the database connection
?>
